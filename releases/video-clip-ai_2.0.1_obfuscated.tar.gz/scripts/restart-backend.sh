#!/bin/bash
# Restart video-clip-ai backend (force kill if stuck during shutdown)
echo "Stopping video-clip-ai-backend..."
sudo systemctl stop video-clip-ai-backend 2>/dev/null
sleep 2
if systemctl is-active video-clip-ai-backend &>/dev/null; then
    echo "Service stuck, force killing..."
    sudo systemctl kill -s KILL video-clip-ai-backend 2>/dev/null
    sleep 2
fi
echo "Starting video-clip-ai-backend..."
sudo systemctl start video-clip-ai-backend
sleep 5
systemctl status video-clip-ai-backend --no-pager
echo ""
echo "Checking generator logs..."
journalctl -u video-clip-ai-backend -n 30 --no-pager | grep -E "Loaded settings|Scanning|Initial|complete|encode_sec|Error|Starting"
