#!/bin/bash
# Start video-clip-ai backend (native)
cd "$(dirname "$0")/.."
source backend/venv/bin/activate
export $(grep -v '^#' .env | xargs)
exec uvicorn main:app --host 0.0.0.0 --port ${BACKEND_PORT:-3030} --app-dir backend --env-file ../.env
