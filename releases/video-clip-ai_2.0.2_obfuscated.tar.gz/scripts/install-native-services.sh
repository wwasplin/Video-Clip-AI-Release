#!/bin/bash
# Install systemd services for native (non-Docker) video-clip-ai
# Run: sudo bash scripts/install-native-services.sh
# Patches unit files with the actual project path and run user.
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
RUN_USER="${SUDO_USER:-$USER}"
NPM_PATH="$(command -v npm 2>/dev/null || echo "/usr/bin/npm")"

echo "Installing video-clip-ai systemd services..."
echo "  Project: $PROJECT_DIR"
echo "  User: $RUN_USER"

# Patch paths and user in unit files
mkdir -p "$PROJECT_DIR/systemd-generated"
sed -e "s|/mnt/backup/cursor/video-clip-ai|$PROJECT_DIR|g" \
    -e "s|User=apr|User=$RUN_USER|g" \
    -e "s|Group=apr|Group=$RUN_USER|g" \
    "$PROJECT_DIR/systemd/video-clip-ai-backend.service" \
    > "$PROJECT_DIR/systemd-generated/video-clip-ai-backend.service"

sed -e "s|/mnt/backup/cursor/video-clip-ai|$PROJECT_DIR|g" \
    -e "s|User=apr|User=$RUN_USER|g" \
    -e "s|Group=apr|Group=$RUN_USER|g" \
    -e "s|ExecStart=.*|ExecStart=$NPM_PATH run dev -- --host 0.0.0.0 --port 3020 --strictPort|" \
    -e "s|WorkingDirectory=.*|WorkingDirectory=$PROJECT_DIR/frontend|" \
    "$PROJECT_DIR/systemd/video-clip-ai-frontend.service" \
    > "$PROJECT_DIR/systemd-generated/video-clip-ai-frontend.service"

sudo cp "$PROJECT_DIR/systemd-generated/video-clip-ai-backend.service" /etc/systemd/system/
sudo cp "$PROJECT_DIR/systemd-generated/video-clip-ai-frontend.service" /etc/systemd/system/

systemctl daemon-reload
systemctl enable video-clip-ai-backend video-clip-ai-frontend

echo "Done. Start services with:"
echo "  sudo systemctl start video-clip-ai-backend video-clip-ai-frontend"
echo "Or they will start automatically on boot."
