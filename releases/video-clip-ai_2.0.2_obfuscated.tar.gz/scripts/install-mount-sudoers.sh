#!/bin/bash
# Allow video-clip-ai backend users to run mount/umount without password.
# Required for SMB share mounting when running as non-root.
# Usage:
#   sudo bash scripts/install-mount-sudoers.sh           # Add current user only
#   sudo bash scripts/install-mount-sudoers.sh user1 user2  # Add listed users
# Run once per deployment so every user that can run the backend has passwordless mount/umount.

set -e
SUDOERS_FILE="/etc/sudoers.d/video-clip-ai-mount"

if [ $# -eq 0 ]; then
  USERS="$(whoami)"
else
  USERS="$*"
fi

echo "Creating sudoers file for users: $USERS"
{
  echo "# Allow video-clip-ai backend users to mount SMB/CIFS and unmount"
  for u in $USERS; do
    echo "$u ALL=(ALL) NOPASSWD: /usr/bin/mount"
    echo "$u ALL=(ALL) NOPASSWD: /usr/bin/umount"
  done
} > "$SUDOERS_FILE"
chmod 440 "$SUDOERS_FILE"
visudo -c -f "$SUDOERS_FILE"
echo "Done. SMB mounts should now work. Restart the backend to retry mounts."
