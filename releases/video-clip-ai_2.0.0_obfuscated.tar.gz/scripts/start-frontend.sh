#!/bin/bash
# Start video-clip-ai frontend (native)
cd "$(dirname "$0")/../frontend"
export $(grep -v '^#' ../.env | xargs)
exec npm run dev -- --host 0.0.0.0 --port ${FRONTEND_PORT:-3020}
