#!/bin/bash
# Comprehensive API test - run after backend is up
set -e
API="http://127.0.0.1:3030"
echo "=== Video Clip AI - API Test ==="

echo ""
echo "1. Health check..."
curl -s -m 5 "$API/api/health" | python3 -c "import sys,json; d=json.load(sys.stdin); print('   OK' if d.get('status')=='healthy' else '   FAIL:', d)" 2>/dev/null || echo "   FAIL: timeout/error"

echo ""
echo "2. Login..."
TOKEN=$(curl -s -m 10 -X POST "$API/api/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin&password=admin" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(d.get('access_token',''))
" 2>/dev/null)
if [ -z "$TOKEN" ]; then
  echo "   FAIL: no token"
  exit 1
fi
echo "   OK (token len: ${#TOKEN})"

echo ""
echo "3. Clips list..."
CLIPS=$(curl -s -m 10 "$API/api/clips/?limit=10" -H "Authorization: Bearer $TOKEN" | python3 -c "
import sys,json
d=json.load(sys.stdin)
print(len(d) if isinstance(d,list) else 0)
" 2>/dev/null)
echo "   OK: $CLIPS clips"

echo ""
echo "4. Clip video (stream)..."
VID=$(curl -s -m 15 -o /tmp/test_clip_vid.mp4 -w "%{http_code}" "$API/api/clips/1/video?token=$TOKEN" 2>/dev/null)
SIZE=$(stat -c%s /tmp/test_clip_vid.mp4 2>/dev/null || echo 0)
echo "   HTTP $VID, size $SIZE bytes"

echo ""
echo "5. Settings clip-generation..."
SET=$(curl -s -m 10 "$API/api/settings/clip-generation" -H "Authorization: Bearer $TOKEN" 2>/dev/null)
echo "   $(echo $SET | python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if 'unviewed_clips_quota' in d else 'FAIL')" 2>/dev/null || echo "FAIL")"

echo ""
echo "6. Clip generation progress..."
PROG=$(curl -s -m 10 "$API/api/settings/clip-generation/progress" -H "Authorization: Bearer $TOKEN" 2>/dev/null)
echo "   $(echo $PROG | python3 -c "import sys,json; d=json.load(sys.stdin); print('OK -', d.get('unviewed_count',0), '/', d.get('quota',0), 'unviewed')" 2>/dev/null || echo "FAIL")"

echo ""
echo "7. Network shares..."
SHARES=$(curl -s -m 10 "$API/api/network-shares/" -H "Authorization: Bearer $TOKEN" 2>/dev/null)
MNT=$(echo "$SHARES" | python3 -c "
import sys,json
d=json.load(sys.stdin)
m=sum(1 for s in d if s.get('is_mounted'))
print(f'{m}/{len(d)} mounted')
" 2>/dev/null)
echo "   OK: $MNT"

echo ""
echo "8. Frontend proxy (video via 3020)..."
curl -s -m 15 -o /tmp/test_proxy_vid.mp4 -w "HTTP %{http_code}\n" "http://127.0.0.1:3020/api/clips/1/video?token=$TOKEN" 2>/dev/null
PSIZE=$(stat -c%s /tmp/test_proxy_vid.mp4 2>/dev/null || echo 0)
echo "   Proxy video size: $PSIZE bytes"

echo ""
echo "=== All tests complete ==="
