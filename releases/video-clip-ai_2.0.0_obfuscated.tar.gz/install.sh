#!/bin/bash
# Install from a deploy tree (pre-built frontend, backend with or without PyArmor).
# Run from the deploy root after rsync: ./install.sh
# Does not require Node/npm or frontend source; uses frontend/dist and backend venv only.

set -e

INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
BACKEND_DIR="$INSTALL_DIR/backend"
RUN_USER="${SUDO_USER:-$USER}"

msg() { echo "[Video Clip AI] $*"; }

if [ ! -f "$BACKEND_DIR/requirements.txt" ]; then
  msg "Error: Run this script from the deploy root (directory containing backend/ and frontend/dist)."
  exit 1
fi

if [ ! -d "$INSTALL_DIR/frontend/dist" ] || [ ! -f "$INSTALL_DIR/frontend/dist/index.html" ]; then
  msg "Error: frontend/dist not found. Deploy tree should include a pre-built frontend."
  exit 1
fi

msg "Install directory: $INSTALL_DIR"
msg "User: $RUN_USER"

# Backend venv
msg "Setting up Python environment..."
if [ ! -d "$BACKEND_DIR/venv" ]; then
  python3 -m venv "$BACKEND_DIR/venv"
fi
"$BACKEND_DIR/venv/bin/pip" install -q --upgrade pip setuptools wheel
"$BACKEND_DIR/venv/bin/pip" install -q -r "$BACKEND_DIR/requirements.txt"
msg "Backend dependencies installed."

# .env
ENV_FILE="$INSTALL_DIR/.env"
if [ -f "$ENV_FILE" ]; then
  msg "Existing .env found. Backing up to .env.bak"
  cp "$ENV_FILE" "$INSTALL_DIR/.env.bak"
fi
cp "$INSTALL_DIR/.env.example" "$ENV_FILE"
SECRET_KEY=$(openssl rand -hex 32)
sed -i "s|^SECRET_KEY=.*|SECRET_KEY=$SECRET_KEY|" "$ENV_FILE"
chmod 600 "$ENV_FILE"
msg ".env created. Edit .env to set POSTGRES_* and other options."

# Systemd (optional)
if [ -d "$INSTALL_DIR/systemd" ] && [ -f "$INSTALL_DIR/systemd/video-clip-ai-backend.service" ]; then
  echo -n "Install systemd services for autostart? [y/N]: "
  read -r y
  if [ "$y" = "y" ] || [ "$y" = "Y" ]; then
    SED_DIR="${INSTALL_DIR//\//\\/}"
    mkdir -p "$INSTALL_DIR/systemd-generated"
    sed -e "s|/opt/video-clip-ai|$INSTALL_DIR|g" -e "s|User=apr|User=$RUN_USER|g" -e "s|Group=apr|Group=$RUN_USER|g" \
      "$INSTALL_DIR/systemd/video-clip-ai-backend.service" > "$INSTALL_DIR/systemd-generated/video-clip-ai-backend.service"
    sed -e "s|/opt/video-clip-ai|$INSTALL_DIR|g" -e "s|User=apr|User=$RUN_USER|g" -e "s|Group=apr|Group=$RUN_USER|g" \
      "$INSTALL_DIR/systemd/video-clip-ai-frontend.service" > "$INSTALL_DIR/systemd-generated/video-clip-ai-frontend.service"
    sudo cp "$INSTALL_DIR/systemd-generated/video-clip-ai-backend.service" /etc/systemd/system/
    sudo cp "$INSTALL_DIR/systemd-generated/video-clip-ai-frontend.service" /etc/systemd/system/
    sudo systemctl daemon-reload
    sudo systemctl enable video-clip-ai-backend video-clip-ai-frontend
    msg "Systemd services installed and enabled."
    echo -n "Start services now? [y/N]: "
    read -r s
    if [ "$s" = "y" ] || [ "$s" = "Y" ]; then
      sudo systemctl start video-clip-ai-backend video-clip-ai-frontend
      msg "Services started."
    fi
  fi
fi

msg ""
msg "=== Installation complete ==="
msg "  Install path: $INSTALL_DIR"
msg "  Backend:  http://localhost:3030"
msg "  Frontend: http://localhost:3020"
msg ""
msg "Edit $ENV_FILE to set PostgreSQL and other options, then start or restart services."
msg ""
